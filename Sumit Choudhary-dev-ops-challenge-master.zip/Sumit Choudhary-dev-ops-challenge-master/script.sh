 awk '{ print $1}' logfile | sort | uniq -c | sort -nr | head -n 8 | while read a b; do echo "$b $a"; done

